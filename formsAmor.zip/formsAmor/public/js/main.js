document.getElementById("myForm").addEventListener("submit", function(event) {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var isValid = true;
    
    if (name === "") {
      document.getElementById("nameError").textContent = "Por favor, digite seu nome";
      isValid = false;
    } else {
      document.getElementById("nameError").textContent = "";
    }

    if (email === "") {
      document.getElementById("emailError").textContent = "Por favor, digite seu e-mail";
      isValid = false;
    } else {
      document.getElementById("emailError").textContent = "";
    }

    if (phone === "") {
      document.getElementById("phoneError").textContent = "Por favor, digite seu telefone";
      isValid = false;
    } else {
      document.getElementById("phoneError").textContent = "";
    }

    if (isValid == true) {
      let sucess = window.alert("Usuario cadastrado")
    } else {
      event.preventDefault();
    }
  });